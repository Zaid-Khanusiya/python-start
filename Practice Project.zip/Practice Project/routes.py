from app import myapp
from views import *

@myapp.route('/')
def Home():
    return home_view()

@myapp.route('/orders')
def Orders():
    return orders_view()

@myapp.route('/customers')
def Customers():
    return customers_view()

@myapp.route('/add_customer', methods=['POST','GET'])
def AddCustomer():
    return add_customer_view()

@myapp.route('/add_order', methods=['POST','GET'])
def AddOrder():
    return add_order_view

@myapp.route('/edit_customer/<int:id>', methods=['GET', 'POST'])
def EditCustomer(id):
    return edit_customer_view(id)

@myapp.route('/edit_order/<int:id>', methods=['GET', 'POST'])
def EditOrder(id):
    return edit_order_view(id)

@myapp.route('/delete_customer/<int:id>', methods=['GET'])
def DeleteCustomer(id):
    return delete_customer_view(id)

@myapp.route('/delete_order/<int:id>', methods=['GET'])
def DeleteOrder(id):
    return delete_order_view(id)