from flask import request,render_template
from datetime import datetime
from model import *

def home_view():
    return "Hello, this is home page!"

def orders_view():
    orders = Order.query.all()
    all_orders = []
    for x in orders:
        all_orders.append({
            'order_id': x.order_id,
            'customer_id': x.customer_id,
            'order_date': x.order_date,
            'total_amount': x.total_amount,
            'status': x.status
        })
    return all_orders

def customers_view():
    users = Customer.query.all()
    all_users = []
    for x in users:
        all_users.append({
            'customer_id': x.customer_id,
            'first_name': x.first_name,
            'last_name': x.last_name,
            'email': x.email,
            'phone': x.phone,
            'created_at' : x.created_at
        })
    return all_users

def add_customer_view():
    if request.method == "GET":
        return render_template('add_customer.html')
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    phone = request.form['phone']
    new_customer = Customer(
        first_name=first_name,
        last_name=last_name,
        email=email,
        phone=phone,
        created_at=datetime.now()
    )
    db.session.add(new_customer)
    db.session.commit()
    return f"Customer {first_name} added successfully!"

def add_order_view():
    if request.method == "GET":
        return render_template('add_order.html')
    customer_id = request.form['customer_id']
    order_date = datetime.now()
    total_amount = request.form['total_amount']
    status = request.form['status']
    new_order = Order(
        customer_id=customer_id,
        order_date=order_date,
        total_amount=total_amount,
        status=status
    )
    db.session.add(new_order)
    db.session.commit()
    return f"Order added successfully!"

def edit_customer_view(id):
    user = Customer.query.get_or_404(id)
    if request.method == "POST":
        user.first_name = request.form['first_name']
        user.last_name = request.form['last_name']
        user.email = request.form['email']
        user.phone = request.form['phone']
        db.session.commit()
        return f"Customer {user.first_name} updated successfully!"
    return render_template('edit_customer.html',user=user)

def edit_order_view(id):
    order = Order.query.get_or_404(id)
    if request.method == "POST":
        order.order_id = request.form['order_id']
        order.customer_id = request.form['customer_id']
        order.order_date = request.form['order_date']
        order.total_amount = request.form['total_amount']
        order.status = request.form['status']
        db.session.commit()
        return f"Order {order.order_id} updated successfully!"
    return render_template('edit_order.html',order=order)

def delete_customer_view(id):
    user = Customer.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    return f"Customer {user.first_name} deleted successfully!"

def delete_order_view(id):
    order = Order.query.get_or_404(id)
    db.session.delete(order)
    db.session.commit()
    return f"Order {order.order_id} deleted successfully!"